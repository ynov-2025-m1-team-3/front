import RegisterForm from "../../../components/RegisterForm";

function Register() {

  return (
      <RegisterForm />
  );
}

export default Register;